#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
void syscall_init(void);
// int fibonnaci(int n);
// int max_of_four_int(int a, int b, int c, int d);
#endif /* userprog/syscall.h */
